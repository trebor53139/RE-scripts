﻿function Ensure-WingetInstalled


 { # start winget install function
    # Check if the winget command exists
    if (Get-Command winget -ErrorAction SilentlyContinue) {
        Write-Host "Winget package manager is already installed." -ForegroundColor Green
    }
    else {
        Read-Host "Winget package manager is not installed. Please press enter to open ms store and install manually" -ForegroundColor Yellow
         Start-Process "ms-windows-store://pdp/?productid=9nblggh4nns1"
         }

        
} # end winget install function




function displaymenu
{
    Write-Host "Select a task to perform (1-6):"
    Write-Host "1. Install a program using winget"
    Write-Host "2. Uninstall a program using winget"
    Write-Host "3. Create a JSON backup file of installed programs"
    Write-Host "4. Reinstall programs from JSON file"
    Write-Host "5. Upgrade programs to the latest version"
    }
 

function InstallProgram 
    
 { # start installprogram function
 do
 {

$program = Read-Host "Enter the program name to installl:"
winget install --exact --source winget $program


$installcheck=winget search $program
if($installcheck -match "Found an existing package already installed." )
{
Write-Host "The program is already installed"
}
elseif($installcheck -match "No package found matching input criteria." )
{
Write-Host "The specified program is not available for install using winget."
}

$anotherprogram=Read-Host "Do you want to install another program 1 - yes 2 - no"

}while($anotherprogram -eq 1)

} # end install program function

function uninstall-program
{ #start uninstall function
do
{

$program = Read-Host "Enter the program name to uninstalll:"
winget uninstall $program
write-host "The program " $program "has been uninstalled successfully."
$anotherprogram=Read-Host "Do you want to uninstall another program 1 - yes 2 - no"

}while($anotherprogram -eq 1)

} # end uninstall function

function jsonbackup
{ #start backup function
# Define backup file path
$backupPath = "C:\temp\winget-installed-programs-backup.json"

# Ensure the C:\temp directory exists; create it if it doesn't
if (!(Test-Path "C:\temp")) {
    New-Item -ItemType Directory -Path "C:\temp" | Out-Null
}

# If the JSON backup file already exists, remove it to enforce overwrite
if (Test-Path $backupPath) {
    Remove-Item $backupPath -Force
}

# Create JSON backup using winget and suppress the command's output
winget export --output "$backupPath" --accept-source-agreements *> $null

# Verify if the backup file was successfully created
if (Test-Path $backupPath) {
    # Read the backup JSON file
    $jsonContent = Get-Content -Raw $backupPath | ConvertFrom-Json
    
    
    # Output a success message with the total number of programs backed up
    Write-Output "Backup completed successfully. winget installed programs backed up to the following location C:\temp\winget-installed-programs-backup.json opening file location"
    
    # Open the C:\temp directory
    Start-Process "C:\temp"
} else {
    Write-Output "Backup file creation failed."
}


} #end backup function

function reinstallprograms
{ #start reinstall function
# Inform the user about the process.
Write-Host "This script will reinstall programs using Winget's import function."
Write-Host "Ensure that the backup JSON file 'winget-installed-programs-backup.json' is located in C:\temp."
Write-Host ""
Write-Host "Press Enter once the file is in the correct location..."
$null = Read-Host

# Define the path to the backup JSON file.
$backupFile = "C:\temp\winget-installed-programs-backup.json"
# Run Winget import and redirect all output (both standard and error) to $null.
winget import -i $backupFile > $null 2>&1

# Check if the import process was successful.
if ($LASTEXITCODE -ne 0) {
    Write-Host "Winget import encountered errors. Please check your backup file and try again." -ForegroundColor Red
} else {
    Write-Host "Winget import completed successfully." -ForegroundColor Green
}


}# end reinstall function


function upgradeprogram
{ #start function
do
{
# Retrieve available package upgrades
 $upgrades = winget upgrade --accept-source-agreements
  
   # Check if there are no packages available for upgrade
    if ($upgrades -match "No installed package found matching input criteria") {
        Write-Output "No packages are available for upgrade."
    } else {
        Write-Output "The following packages are available for upgrade:"
        Write-Output $upgrades


 # Prompt user to choose between a single package upgrade or upgrading all packages.
        do {
            $upgradechoice = [int](Read-Host "Do you want to upgrade a single program (Enter 1) or all programs (Enter 2)")
        } while ($upgradechoice -lt 1 -or $upgradechoice -gt 2)

        Write-Host "If only one program is available for upgrade, either option will work."

        if ($upgradechoice -eq 1) {
            # Prompt for the name of the package to upgrade
            $programname = Read-Host "Please enter the name of the program you want to upgrade:"
            winget upgrade --exact --source winget $programname > $null 2>&1
            Write-Host "Upgrading the specified program..."
            Write-Host "Program updated successfully."
        }
         elseif ($upgradechoice -eq 2) {
            # Upgrade all available packages
            winget upgrade --all
            Write-Host "All programs updated successfully."
        }
         }
         do
         {
         $upgraderunagain=Read-Host "Do you want to run the upgrade program again 1 -yes 2-no"
         }until ($upgraderunagain -match "^[1-2]$") # error check

         }while($upgraderunagain -eq 1) # end do while for upgrade run again


} #end upgrade function

Ensure-WingetInstalled
Read-Host "Press Enter to begin first run of winget program"



do
{
cls

    do
    {
    displaymenu
   $userchoice=Read-Host "Which option do you want to run? Choose 1-5" # user choice input
   }
until ($userchoice -match "^[1-5]$") # error check

switch($userchoice)
{ #start switch case

1{
installProgram
}

2{
uninstall-program
}
3{
jsonbackup
}
4
{
reinstallprograms
}
5
{
upgradeprogram
}


} # end switch case

$runmainagain =Read-Host "Do you want to run the program again 1-yes 2-no"

}while($runmainagain -eq 1) # end run main program loop

if($runmainagain -eq 2)
{
Write-Host "Program Complete " -ForegroundColor Green
}



    