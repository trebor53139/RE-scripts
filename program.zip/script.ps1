﻿#name: Robet Ehrhart
#date: 3/11/2024
#to run script in cmd run start.bat as admin

#variable declarations
[int]$userchoice
[int]$runagain


function displaymenu{

Write-Host "Please Choose one of the following options: "
Write-Host "1 - disk cleanup"
Write-Host "2 - Clear print queue"
Write-Host "3 - network reset"
Write-Host "4 - disable ipv6"
Write-Host "5 - run dism commands"
Write-Host "6 - run sfc"
Write-Host "7 - run chkdsk"
write-host "8 - repair wmi"
}
#end displaymenu

function diskclean
{
cleanmgr /sagerun
Write-host "you ran a disk cleanup"
}
#end diskclean

function clearqueue
{
Stop-Service -Name Spooler -Force
Remove-Item -Path "C:\Windows\System32\spool\PRINTERS\*"
Start-Service -Name Spooler

write-host "You've cleared the print jobs" 
} #end clearqueue


function netreset
{
netsh winsock reset
netsh int ip reset
netsh advfirewall reset
ipconfig /flushdns
ipconfig /release
ipconfig /renew
write-host "you've done a network reset. You're system will restart in 2 minutes"
shutdown /r /t 120 
} # end netreset


function disableipv6
{

Get-NetAdapter | ForEach-Object { Disable-NetAdapterBinding -InterfaceAlias $_.Name -ComponentID ms_tcpip6 }
ipconfig /release
ipconfig /renew
ipconfig /flushdns
ipconfig /registerdns

write-host "Ipv6 has been disabled on on all network adapters"
write-host "The IP address has been refreshed"
write-host "The DNS cache has been flushed."
}# end disableipv6

function dismcmd
{
DISM /Online /Cleanup-Image /CheckHealth
DISM /Online /Cleanup-Image /Scanhealth
DISM /Online /Cleanup-Image /RestoreHealth
cls 
write-host "The dism commands completed succesfully "

} # end dismcmd


function repairwmi
{
do # start error loop
{
write-host "do you want to try and salvage or reset the wmi repository (1-salvage 2-reset 3-neither)"
[int]$wmichoice=read-host
}while($wmichoice -lt 1 -or $wmichoice -gt 3) # error check
if ($wmichoice -eq 1)
{
winmgmt /salvagerepository
winmgmt /verifyrepository
}

elseif ($wmichoice -eq 2)
{
restart-service  winmgmt -Force
winmgmt /resetrepository
shutdown /r /t 120 
}
else
{
Write-Host "You've choosen to do neither a reset or salvage"
} # end wmi repair

}
do #start runagain loop
{

displaymenu
do
{
# input user choice
Write-host "What is your choice? (enter 1-8)"
$userchoice=read-host
}while($userchoice -lt 1 -or $userchoice -gt 8) # error check

switch($userchoice)
{ #start switch statement
1{
diskclean
}
2 
{
clearqueue
}
3
{
netreset
}
4
{
disableipv6
}
5
{
dismcmd
}
6
{
sfc /scannow
}
7
{
chkdsk /f /r /x
cls
Write-Host " the chkdsk command completed successfully"
}
8{
repairwmi
}
} #end switch statement

do # start error check loop
{
Write-Host "Do you want to run this program again? 1-yes 2-no"
[int]$runagain=Read-Host
}while($runagain -lt 1 -or $runagain -gt 2) # end error Check
} while($runagain -eq 1) #end run again loop
if ($runagain -eq 2)
{
Write-Host "program complete"
}
